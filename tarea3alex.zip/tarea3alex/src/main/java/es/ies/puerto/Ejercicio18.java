package es.ies.puerto;

import java.util.Scanner;

public class Ejercicio18 {
public static void main(String[] args) {
            }
}