package es.ies.puerto;

import java.util.Scanner;

public class Ejercicio17 {
public static void main(String[] args) {
            }
}