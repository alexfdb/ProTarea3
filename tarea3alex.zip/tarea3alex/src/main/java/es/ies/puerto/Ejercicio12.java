package es.ies.puerto;

import java.util.Scanner;

public class Ejercicio12 {
public static void main(String[] args) {
            }
}