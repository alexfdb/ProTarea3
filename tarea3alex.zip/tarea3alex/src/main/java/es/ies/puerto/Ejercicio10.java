package es.ies.puerto;

public class Ejercicio10 {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}