package es.ies.puerto;

import java.util.Scanner;

public class Ejercicio14 {
public static void main(String[] args) {
            }
}