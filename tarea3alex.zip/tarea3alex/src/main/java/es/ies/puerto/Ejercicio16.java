package es.ies.puerto;

import java.util.Scanner;

public class Ejercicio16 {
public static void main(String[] args) {
            }
}