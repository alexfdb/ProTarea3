package es.ies.puerto;

import java.util.Scanner;

public class Ejercicio13 {
public static void main(String[] args) {
            }
}